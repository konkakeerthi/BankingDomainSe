package testscript;

//import java.util.concurrent.TimeUnit;

import java.util.List;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.Assert;

import org.testng.annotations.BeforeMethod;

import commonlibrary.Browser;
import commonlibrary.Utility;



public class TestCase {
    
	private static WebDriver driver;
	@Test
	public static void verifyaccountdetails() {
		// TODO Auto-generated method stub
				
         Utility.login();
		//get account name
		String name = driver.findElement(By.xpath("//p[@class='loginlink']")).getText();
		
		//assert accountname
		String Expectedvalue = "Keerthi";
		
		try{
		assert.assertequals(name,Expectedvalue);		
		System.out.println("AccountName verified");				
			
		}
		catch(Exception ex)
		{
			System.out.println("Exception occured");
		}
		
		
		//balance of account
		String amount = driver.findElement(By.xpath("//span[@id='SavingTotalSummary']")).getText();
		//assert
		int ExpectedAmount = 45647;
		
		assert.assertequals(amount,ExpectedAmount)
	}
		
			
	------------------------------------------------------------------------------------------
	//Scenario : 2
		@Test
		public void verifybeneficiery()
		{
		//click on Funds Transfer
		driver.findElement(By.xpath("//img[@alt='Funds Transfer']")).click();
		//click on GO
		driver.findElement(By.xpath("//img[contains(text(),Go)]/following::img[3]")).click();
		
		
		//beneficiery List
		Select beneficiery = new Select(driver.findElement(By.cssSelector("select#fldBeneId")));
		List<WebElement> bcount = beneficiery.getOptions();
		for(int i=0;i<bcount.size();i++){

			String svalue = bcount.get(i).getText();
			System.out.println(bcount);
			String Expectedname="jhr"
			assert.assertequals(svalue,Expectedname);
			System.out.println("TC Pass");
			
		}
			
		}
	Utility.logout();			
		
		}
