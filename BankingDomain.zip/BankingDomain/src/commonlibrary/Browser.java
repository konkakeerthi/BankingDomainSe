package commonlibrary;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

public class Browser {
	
    static WebDriver driver = null;
	
	@Beforemethod
    public void openbrowser()
    {
    	
	String exePath = "C:\\Users\\admin\\Downloads\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver", exePath);
	driver =  new ChromeDriver();
	driver.manage().window().maximize();
	//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.get("http://www.hdfcbank.com/");
	
    }
    


}
