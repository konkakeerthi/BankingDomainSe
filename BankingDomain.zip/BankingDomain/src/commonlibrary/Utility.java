package commonlibrary;

import org.openqa.selenium.By;

public class Utility extends Browser {
	
	
	public static void login()
	{
		driver.findElement(By.id("loginsubmit")).click();
	    ////a[@class='homeloginbtn']--xpath
	    
	    //switch to new window
		String handle = driver.getWindowHandle();
		driver.switchTo().window(handle);
		
		//continue to banking
		driver.findElement(By.xpath("//a[@class='btn btn-default redBtn']")).click();
		/*
		// switch to the frame
		driver.switchTo().frame("login_page");

		// find the text box and write to it 
		driver.findElement(By.className("input_password")).sendKeys("123456");
		

		// switch back to main window
		driver.switchTo().defaultContent();*/
		
		//Login		
		driver.findElement(By.xpath("//input[@name='fldLoginUserId']")).click();
		//continue
		driver.findElement(By.xpath("//img[contains(@src,'continue')]")).click();
		//password
		driver.findElement(By.xpath("//input[@class='input_password']")).click();
		//Login
		driver.findElement(By.xpath("//img[@src='/gif/login_new1.gif']")).click();
		

	}
	
	
	public static void logout()
	{
		driver.findElement(By.xpath("//img[@alt='Log Out']")).click();
	}

}
